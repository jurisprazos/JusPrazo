import os
import json
from google import genai
from google.genai import types
import pypdf

client = genai.Client()

def extrair_texto_pdf(caminho_pdf: str) -> str:
    texto = ""
    with open(caminho_pdf, 'rb') as f:
        reader = pypdf.PdfReader(f)
        for page in reader.pages:
            t = page.extract_text()
            if t:
                texto += t + "\n"
    return texto

def analisar_autos_juridicos(caminho_pdf: str) -> dict:
    texto_autos = extrair_texto_pdf(caminho_pdf)
    
    prompt = """
    Você é um advogado especialista em direito processual brasileiro e analista do JurisPrazos.
    Analise os autos processuais abaixo, identifique o ato de intimação/citação, o número do processo (CNJ) e calcule o prazo legal (CPC/2015 em dias úteis ou Lei 9.099/95).
    
    REGRA D-1 OBRIGATÓRIA: O sistema exige o protocolo no dia útil imediatamente anterior à data fatal (D-1).

    Retorne APENAS um JSON estrito com esta estrutura:
    {
      "numero_processo": "0000000-00.2026.8.15.0000",
      "ato_processual": "Ex: Apelação / Contestação",
      "data_fatal": "YYYY-MM-DD",
      "data_d_minus_1": "YYYY-MM-DD",
      "fundamentacao": "Ex: Art. 1.003 do CPC"
    }
    """

    response = client.models.generate_content(
        model='gemini-2.5-flash',
        contents=[
            types.Part.from_text(text=prompt),
            types.Part.from_text(text=f"AUTOS DO PROCESSO:\n{texto_autos[:30000]}")
        ],
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            temperature=0.1
        )
    )
    return json.loads(response.text)
