CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    tipo VARCHAR(50) CHECK (tipo IN ('ADMINISTRADOR', 'ADVOGADO')) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS processos (
    id SERIAL PRIMARY KEY,
    numero_cnj VARCHAR(50) UNIQUE NOT NULL,
    cliente VARCHAR(255) NOT NULL,
    integra_pdf_url TEXT NOT NULL,
    advogado_id INT REFERENCES usuarios(id) ON DELETE SET NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS prazos (
    id SERIAL PRIMARY KEY,
    processo_id INT REFERENCES processos(id) ON DELETE CASCADE,
    advogado_id INT REFERENCES usuarios(id) ON DELETE CASCADE,
    descricao_ato TEXT NOT NULL,
    data_fatal DATE NOT NULL,
    data_d_minus_1 DATE NOT NULL,
    status VARCHAR(50) CHECK (status IN ('PENDENTE', 'CUMPRIDO', 'EM_EXTENSAO', 'ATRASADO')) DEFAULT 'PENDENTE',
    protocolo_pdf_url TEXT,
    motivo_prorrogacao TEXT,
    aprovado_prorrogacao BOOLEAN DEFAULT FALSE,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir Administrador Anderson Bismark
INSERT INTO usuarios (nome, email, senha, tipo) 
VALUES ('Anderson Bismark', 'anderson-bpn@hotmail.com', 'admin123', 'ADMINISTRADOR')
ON CONFLICT (email) DO NOTHING;
