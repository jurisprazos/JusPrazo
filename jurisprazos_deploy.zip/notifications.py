import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import requests

EMAIL_ADMIN = "anderson-bpn@hotmail.com"
WHATSAPP_API = os.getenv("WHATSAPP_API", "https://api.sua-gateway-whatsapp.com/send")
WHATSAPP_TOKEN = os.getenv("WHATSAPP_TOKEN", "seu_token")
NUMERO_WHATSAPP_ADMIN = "5583991061441"

def enviar_email_cumprimento(nome_advogado, cnj, ato, caminho_pdf_protocolo):
    remetente = os.getenv("SMTP_EMAIL", "sistema@jurisprazo.site")
    senha_email = os.getenv("SMTP_SENHA", "sua_senha")
    
    msg = MIMEMultipart()
    msg['From'] = remetente
    msg['To'] = EMAIL_ADMIN
    msg['Subject'] = f"[JURISPAZOS] Prazo Cumprido - Processo {cnj}"
    
    corpo = f"O advogado {nome_advogado} acabou de cumprir o prazo do ato '{ato}' referente ao processo {cnj}.\n\nSegue em anexo o comprovante de protocolo em PDF."
    msg.attach(MIMEText(corpo, 'plain'))
    
    try:
        with open(caminho_pdf_protocolo, "rb") as file_attachment:
            parte = MIMEBase('application', 'octet-stream')
            parte.set_payload(file_attachment.read())
            encoders.encode_base64(parte)
            parte.add_header('Content-Disposition', f'attachment; filename="protocolo_{cnj}.pdf"')
            msg.attach(parte)
            
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(remetente, senha_email)
        server.sendmail(remetente, EMAIL_ADMIN, msg.as_string())
        server.quit()
        print("[+] E-mail enviado com sucesso para Anderson Bismark.")
    except Exception as e:
        print(f"[-] Erro ao enviar e-mail: {e}")

def enviar_whatsapp_alerta(mensagem):
    payload = {
        "phone": NUMERO_WHATSAPP_ADMIN,
        "message": mensagem
    }
    headers = {"Authorization": f"Bearer {WHATSAPP_TOKEN}"}
    try:
        requests.post(WHATSAPP_API, json=payload, headers=headers)
        print("[+] WhatsApp enviado para o Administrador.")
    except Exception as e:
        print(f"[-] Erro no WhatsApp: {e}")
