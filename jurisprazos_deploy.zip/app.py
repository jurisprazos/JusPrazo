import os
from flask import Flask, render_template, request, redirect, url_for, session, flash
import psycopg2
from ai_analyzer import analisar_autos_juridicos
from notifications import enviar_email_cumprimento, enviar_whatsapp_alerta

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "juris_prazos_secret_key_2026")

def get_db():
    return psycopg2.connect(os.getenv("DATABASE_URL"))

@app.route('/')
def index():
    if 'usuario_id' in session:
        if session['tipo'] == 'ADMINISTRADOR':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('advogado_dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT id, nome, tipo, senha FROM usuarios WHERE email = %s", (email,))
        user = cur.fetchone()
        cur.close()
        conn.close()
        
        if user and user[3] == senha:
            session['usuario_id'] = user[0]
            session['nome'] = user[1]
            session['tipo'] = user[2]
            return redirect(url_for('index'))
        flash('Credenciais inválidas.', 'danger')
    return render_template('login.html')

@app.route('/admin/dashboard', methods=['GET', 'POST'])
def admin_dashboard():
    if session.get('tipo') != 'ADMINISTRADOR':
        return redirect(url_for('login'))
        
    conn = get_db()
    cur = conn.cursor()
    
    if request.method == 'POST':
        if 'cadastrar_advogado' in request.form:
            nome = request.form['nome']
            email = request.form['email']
            senha = request.form['senha']
            cur.execute("INSERT INTO usuarios (nome, email, senha, tipo) VALUES (%s, %s, %s, 'ADVOGADO')", (nome, email, senha))
            conn.commit()
            flash('Advogado cadastrado com sucesso!', 'success')
            
        elif 'cadastrar_processo' in request.form:
            file = request.files['arquivo_pdf']
            advogado_id = request.form['advogado_id']
            caminho = f"/tmp/{file.filename}"
            file.save(caminho)
            
            dados = analisar_autos_juridicos(caminho)
            
            cur.execute("INSERT INTO processos (numero_cnj, cliente, integra_pdf_url, advogado_id) VALUES (%s, %s, %s, %s) RETURNING id",
                        (dados['numero_processo'], "Cliente Processual", caminho, advogado_id))
            proc_id = cur.fetchone()[0]
            
            cur.execute("INSERT INTO prazos (processo_id, advogado_id, descricao_ato, data_fatal, data_d_minus_1) VALUES (%s, %s, %s, %s, %s)",
                        (proc_id, advogado_id, dados['ato_processual'], dados['data_fatal'], dados['data_d_minus_1']))
            conn.commit()
            flash('Processo cadastrado e prazos calculados pela IA!', 'success')

    cur.execute("SELECT p.id, pr.numero_cnj, p.descricao_ato, p.data_fatal, p.data_d_minus_1, p.status, u.nome FROM prazos p JOIN processos pr ON p.processo_id = pr.id JOIN usuarios u ON p.advogado_id = u.id")
    prazos = cur.fetchall()
    
    cur.execute("SELECT id, nome, email FROM usuarios WHERE tipo = 'ADVOGADO'")
    advogados = cur.fetchall()
    
    cur.close()
    conn.close()
    return render_template('admin_dashboard.html', prazos=prazos, advogados=advogados)

@app.route('/advogado/dashboard', methods=['GET', 'POST'])
def advogado_dashboard():
    if session.get('tipo') != 'ADVOGADO':
        return redirect(url_for('login'))
        
    adv_id = session['usuario_id']
    conn = get_db()
    cur = conn.cursor()
    
    if request.method == 'POST':
        if 'cumprir_prazo' in request.form:
            prazo_id = request.form['prazo_id']
            protocolo = request.files['protocolo_pdf']
            caminho_prot = f"/tmp/prot_{protocolo.filename}"
            protocolo.save(caminho_prot)
            
            cur.execute("UPDATE prazos SET status = 'CUMPRIDO', protocolo_pdf_url = %s WHERE id = %s", (caminho_prot, prazo_id))
            conn.commit()
            
            cur.execute("SELECT pr.numero_cnj, p.descricao_ato FROM prazos p JOIN processos pr ON p.processo_id = pr.id WHERE p.id = %s", (prazo_id,))
            res = cur.fetchone()
            enviar_email_cumprimento(session['nome'], res[0], res[1], caminho_prot)
            flash('Prazo cumprido! O Administrador foi notificado por e-mail e WhatsApp.', 'success')
            
        elif 'pedir_remarcacao' in request.form:
            prazo_id = request.form['prazo_id']
            motivo = request.form['motivo']
            
            cur.execute("UPDATE prazos SET motivo_prorrogacao = %s, status = 'EM_EXTENSAO' WHERE id = %s", (motivo, prazo_id))
            conn.commit()
            
            enviar_whatsapp_alerta(f"📋 *SOLICITAÇÃO DE REMARCAÇÃO*\nO advogado {session['nome']} pediu dilação de prazo. Motivo: \"{motivo}\". Acesse o JurisPrazos para aprovar.")
            flash('Solicitação enviada ao Administrador para aprovação via WhatsApp.', 'warning')

    cur.execute("SELECT p.id, pr.numero_cnj, p.descricao_ato, p.data_fatal, p.data_d_minus_1, p.status, pr.integra_pdf_url FROM prazos p JOIN processos pr ON p.processo_id = pr.id WHERE p.advogado_id = %s", (adv_id,))
    meus_prazos = cur.fetchall()
    
    cur.close()
    conn.close()
    return render_template('advogado_dashboard.html', meus_prazos=meus_prazos)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
